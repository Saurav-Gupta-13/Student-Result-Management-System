from tkinter import *
#import self as self
from tkinter import messagebox
import sqlite3
import os
#import pymysql
import sqlite3
from tkinter import messagebox

from PIL import ImageTk  #pil class hai pillow library ke andar
class Login_System: #class isliye define kiya hai kyuki jo bhi function use honga vo structured way mai honga isliye
    def __init__(self,root):
        self.root=root                  #self isliye define kiya hai kyuki jo root hai vo class ka object bana chaiye koi diff path na ban jaye wahi jo class define ke hai ouska part rehna chaiye isliye self ko use kiya hai
        self.root.title("Login System")
        self.root.geometry("1350x700+0+0")
        self.root.config(bg="#021e2f")



#===============colour 2============================
        left_lbl = Label(self.root, bg="#08A3D2", bd=0)
        left_lbl.place(x=0, y=0, relheight=450, width=650)


        # ===loginframe======
        self.txt_email=StringVar()
        self.txt_pass=StringVar()  #user se input lenga fir text variable ke property is place honga jaha bhi place karana hai ousko


        login_frame=Frame(self.root, bd=2,relief=RIDGE,bg="white")
        login_frame.place(x=370, y=90, width=650, height=460)

        self.left = ImageTk.PhotoImage(file="images/logo.jpg")
        left = Label(self.root,image=self.left).place(x=80, y=120, width=400, height=400)



        title=Label(login_frame,text="LOGIN HERE",font=("Elephant",25,"bold"),bg="white").place(x=0,y=30,relwidth=1)

        lbl_user=Label(login_frame,text="Email Address",font=("Andalus",15),bg="white",fg="#767171").place(x=200,y=100)
        self.txt_email=StringVar()
        self.txt_pass=StringVar()  #user se input lenga fir text variable ke property is place honga jaha bhi place karana hai ousko
        txt_email=Entry(login_frame,textvariable=self.txt_email,font=("times new roman",15),bg="#ECECEC").place(x=200,y=140,width=250,height=23)

        lbl_pass=Label(login_frame,text="Pass",font=("Andalus",15),bg="white",fg="#767171").place(x=200,y=200)
        txt_pass=Entry(login_frame,textvariable=self.txt_pass,show="*",font=("times new roman",15),bg="#ECECEC").place(x=200,y=240,width=250,height=23)

        btn_reg = Button(login_frame,command=self.register_window ,text="Register new Account?", font=("times new roman",12),bg="white",bd=0,fg="#B00857").place(x=200, y=270)


        btn_login= Button(login_frame,command=self.login, text="Log In", font=("Arial Rounded MT Bold",15),fg="white",activeforeground="white",bg="#B00857",cursor="hand2").place(x=230,y=310,height=40,width=180)
        # command ko login window call karne ke liye use kiya hai


        hr=Label(login_frame,bg="lightgrey").place(x=200,y=380,width=250,height=2)
        or_= Label(login_frame,text="OR",bg="white",fg="lightgrey",font=("times new roman",15,"bold")).place(x=300, y=366)

        btn_forgot=Button(login_frame,text="Forgot Password",font=("times new roman",13),bg="white",fg="#00759E",bd=0,activeforeground="#00759E",activebackground="white").place(x=250,y=390)

    def register_window(self):
        self.root.destroy()
        import register


    def login(self):
        if self.txt_email.get()=="" or self.txt_pass.get()=="":
            messagebox.showerror("Error", "All fields are required", parent=self.root)
        else:
            try:
                con = sqlite3.connect(database="rms.db")
                cur = con.cursor()
                cur.execute("select * from employee where email=? and password=?", (self.txt_email.get(),self.txt_pass.get()))
                row = cur.fetchone()
                if row==None:
                    messagebox.showerror("Error", "Invalid Username or password", parent=self.root)
                else:
                    messagebox.showinfo("Success",f"Welcome:{self.txt_email.get()}", parent=self.root)
                    self.root.destroy()
                    os.system("python dashboard.py")

                con.close()
            except Exception as es:
                messagebox.showerror("Error", f"Error Due to: {str(es)}", parent=self.root)


root = Tk()
obj = Login_System(root)
root.mainloop()
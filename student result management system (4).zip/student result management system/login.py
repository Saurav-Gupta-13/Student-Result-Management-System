from tkinter import*
from PIL import Image,ImageTk, ImageDraw #pip install Pillow
from datetime import*
import time
from math import*
class Login_window:
    def __init__(self,root):
        self.root=root
        self.root.title("Login system")
        self.root.geometry("1350x700+0+0")
        self.root.config(bg="#021e2f")
        title=Label(self.root,text="saharsh clock",font=("times new roman",50,"bold")).place(x=0,y=50, relwidth=1)
        self.lbl=Label(self.root,bg="white", bd=10, relief=RAISED)
        self.lbl.place(x=450, y=150, height=400,width=400)



root=Tk()
obj=Login_window(root)
root.mainloop()